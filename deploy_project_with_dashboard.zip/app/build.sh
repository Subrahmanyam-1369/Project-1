#!/bin/bash
echo "Simulating build process..."
sleep 1
echo "Build complete."
